console.log("Hello");

console.log(document);

var xmlhttp = new XMLHttpRequest();
console.log(xmlhttp);
