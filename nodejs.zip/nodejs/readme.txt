three type of module 
1.Build in module 
2.You can create your module
2.Third party modules


build in module
1)http
2)fs


documents it is not part of nodejs it is part of the javascript


localhost:9000

C:\Users\CDAC\AppData\Roaming\npm\node_modules